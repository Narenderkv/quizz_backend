const jwt = require('jsonwebtoken');

module.exports.register = register;
module.exports.login = login;
module.exports.add_quizzes = add_quizzes;
module.exports.user_quizzes = user_quizzes;
module.exports.attempt_quiz = attempt_quiz;
module.exports.open_quiz = open_quiz;
module.exports.all_quiz = all_quiz;


function register(userdata, pool, callback) {

    var name = '';
    var email = '';
    var password = '';
    pool.getConnection(function (err, connection) {

        if (typeof userdata.email !== 'undefined' && userdata.email !== '') {
            email = userdata.email;
            queryinsert = 'select * from users where email="' + email + '"';

            connection.query(queryinsert, function (errinsert, resultinsert) {
                console.log(resultinsert);
                if (resultinsert.length > 0) {
                    resultJson =
                        '{"replyCode":"error","replyMsg":"Email already exists in db ","cmd":"Register"}\n';
                    callback(200, null, resultJson);
                    return;
                }
            })

        } else {
            resultJson =
                '{"replyCode":"error","replyMsg":"Please Enter email ","cmd":"Register"}\n';
            callback(200, null, resultJson);
            return;
        }

        if (typeof userdata.name !== 'undefined' && userdata.name !== '') {
            name = userdata.name;
        }
        if (typeof userdata.password !== 'undefined' && userdata.password !== '') {
            password = userdata.password;
        }


        queryinsert = 'INSERT INTO users SET email="' + email + '", name="' + name + '", password="' + password + '"';


        connection.query(queryinsert, function (errinsert, resultinsert) {
            if (!errinsert) {
                resultJson = '{"replyCode":"success","replyMsg":"Successfully added"}\n';
                connection.release();
                callback(200, null, resultJson);
                return;
            } else {
                resultJson = '{"replyCode":"error","replyMsg":"' + errinsert.message + '","cmd":"add_user"}\n';
                connection.release();
                callback(400, null, resultJson);
                return;
            }
        });
    });
}
function login(userdata, pool, callback) {

    var ResultArray = "";
    var email = "";
    var password = "";
    if (typeof userdata.password != "undefined" && userdata.password != "") {
        password = userdata.password;
    }
    if (typeof userdata.email != "undefined" && userdata.email != "") {
        email = userdata.email;
    } else {
        resultJson =
            '{"replyCode":"error","replyMsg":"Please insert registered email","cmd":"login"}\n';
        callback(200, null, resultJson);
        return;
    }

    pool.getConnection(function (err, connection) {

        squery = 'SELECT users.* from users WHERE email="' + email + '" AND password="' + password + '" ';
        connection.query(squery, function (err, results) {
            if (!err) {
                console.log(results[0].id, 'is');
                var id = results[0].id
                const token = jwt.sign({ id }, '123456789');
                console.log(token);
                if (results.length > 0) {

                    var id = results[0].id;
                    ResultArray = results[0];

                    resultJson =
                        '{"replyCode":"success","replyMsg": "success", "data":' +
                        JSON.stringify(ResultArray) +
                        ',"Token":"' + token + '"}\n';
                    connection.release();
                    callback(200, null, resultJson);
                    return;

                } else {
                    resultJson =
                        '{"replyCode":"error","replyMsg":"Please check your login credentials.","Token":"login"}\n';
                    connection.release();
                    callback(200, null, resultJson);
                    return;
                }
            } else {
                resultJson =
                    '{"replyCode":"error","replyMsg":"' +
                    err.message +
                    '","cmd":"login"}\n';
                connection.release();
                callback(400, null, resultJson);
                return;
            }
        });
    });
}

function add_quizzes(userdata, pool, callback) {
    var title = '';
    var user_id = '';
    var questions = '';
    pool.getConnection(function (err, connection) {

        if (typeof userdata.title !== 'undefined' && userdata.title !== '') {
            title = userdata.title;
        } else {
            resultJson = '{"replyCode":"error","replyMsg":"title is required","cmd":"add_quizzes"}\n';
            connection.release();
            callback(400, null, resultJson);
            return;

        }
        if (typeof userdata.user_id !== 'undefined' && userdata.user_id !== '' && userdata.user_id !== null) {
            user_id = userdata.user_id;
        } else {
            resultJson = '{"replyCode":"error","replyMsg":"user_id is required","cmd":"add_quizzes"}\n';
            connection.release();
            callback(400, null, resultJson);
            return;

        }
        userdata.questions.forEach((question) => {
            if (
                !question.question ||
                question.answer.length === "" ||
                !question.correct_ans
            ) {
                resultJson = '{"replyCode":"error","replyMsg":"Add All question and answer in quizz","data":' + JSON.stringify(question) + '}\n';
                connection.release();
                callback(400, null, resultJson);
                return;

            }
        });

        connection.query('INSERT INTO quizzes SET ?', { title, user_id }, (err, result) => {
            if (!err) {
                var id = result.insertId
                const questionValues = userdata.questions.map(question => [id, question.question, JSON.stringify(question.answer), question.correct_ans]);

                connection.query('INSERT INTO questions (quiz_id, question,answer,correct_ans) VALUES ?', [questionValues], (err, res) => {
                    if (!err) {
                        resultJson = '{"replyCode":"success","replyMsg":"Successfully added"}\n';
                        connection.release();
                        callback(200, null, resultJson);
                        return;
                    } else {
                        resultJson = '{"replyCode":"error","replyMsg":"' + error.message + '"}\n';
                        connection.release();
                        callback(400, null, resultJson);
                        return;
                    }
                })

            } else {
                resultJson = '{"replyCode":"error","replyMsg":"' + err.message + '","cmd":"add_quizzes"}\n';
                connection.release();
                callback(400, null, resultJson);
                return;
            }
        });
    })
}


function user_quizzes(userdata, pool, callback) {

    var id = "";

    if (typeof userdata.id != "undefined" && userdata.id != "") {
        id = userdata.id;
    } else {
        resultJson =
            '{"replyCode":"error","replyMsg":"User id is required ","cmd":"user_quizzes"}\n';
        callback(200, null, resultJson);
        return;
    }

    pool.getConnection(function (err, connection) {

        squery = 'SELECT * FROM `quizzes`  WHERE user_id="' + id + '"';
        connection.query(squery, function (err, results) {
            if (!err) {


                resultJson =
                    '{"replyCode":"success","replyMsg": "success", "data":' +
                    JSON.stringify(results) +
                    '}\n';
                connection.release();
                callback(200, null, resultJson);
                return;


            } else {
                resultJson =
                    '{"replyCode":"error","replyMsg":"' +
                    err.message +
                    '","cmd":"user_quizzes"}\n';
                connection.release();
                callback(400, null, resultJson);
                return;
            }
        });
    });
}
function open_quiz(userdata, pool, callback) {
    var id = "";
    if (typeof userdata.id != "undefined" && userdata.id != "") {
        id = userdata.id;
    } else {
        resultJson =
            '{"replyCode":"error","replyMsg":"quiz id is required ","cmd":"user_quizzes"}\n';
        callback(200, null, resultJson);
        return;
    }
    pool.getConnection(function (err, connection) {

        squery = 'SELECT id,quiz_id,answer, question  FROM `questions`  WHERE quiz_id="' + id + '"';
        connection.query(squery, function (err, results) {
            if (!err) {


                resultJson =
                    '{"replyCode":"success","replyMsg": "success", "data":' +
                    JSON.stringify(results) +
                    '}\n';
                connection.release();
                callback(200, null, resultJson);
                return;


            } else {
                resultJson =
                    '{"replyCode":"error","replyMsg":"' +
                    err.message +
                    '","cmd":"user_quizzes"}\n';
                connection.release();
                callback(400, null, resultJson);
                return;
            }
        });
    });
}
function attempt_quiz(userdata, pool, callback) {
    var id = "";
    var user_id = "";
    var questions = "";
    var score = 0;
    if (typeof userdata.id != "undefined" && userdata.id != "") {
        id = userdata.id;
    }
    if (typeof userdata.user_id != "undefined" && userdata.user_id != "") {
        user_id = userdata.user_id;
    }
    if (typeof userdata.questions != "undefined" && userdata.questions != "") {
        questions = userdata.questions;
    } else {
        resultJson = '{"replyCode":"error","replyMsg":"Answer is required","cmd":"add_quizzes"}\n';
        connection.release();
        callback(400, null, resultJson);
        return;
    }



    pool.getConnection(function (err, connection) {
        console.log(userdata);
        var score = 0; // Score variable
        var jsonData = [];


        const promises = questions.map((item) => {
            const { question, answer } = item;
            const query = `SELECT * FROM questions WHERE quiz_id='${id}' AND question = '${question}' AND correct_ans LIKE '${answer}'`;
            const query2 = `SELECT * FROM questions WHERE quiz_id='${id}' AND question = '${question}' `;

            return new Promise((resolve, reject) => {
                connection.query(query, (err, results) => {
                    if (err) {
                        console.error('Error executing query:', err);
                        reject(err);
                    } else {
                        connection.query(query2, (err, results) => {
                            if (results.length > 0) {
                                console.log(results[0].question, 'results');
                                var question = results[0].question
                                var answer = results[0].correct_ans
                                jsonData.push({ question, answer })
                                console.log(jsonData, 'jsonData');
                            }
                        })

                        if (results.length > 0) {
                            score += 1;

                        } else {
                        }
                        resolve();
                    }
                });
            });
        });

        // Execute all promises
        Promise.all(promises)
            .then(() => {

                const query = `SELECT * FROM quizzes WHERE id='${id}' AND user_id = '${user_id}'`;
                connection.query(query, (err, results) => {
                    if (results.length) {
                        console.log("inside ");
                        connection.query('UPDATE `quizzes` SET `score` = ' + score + ', `status` = 2 WHERE id = ' + id + '')
                        resultJson = '{"Total Score":' + score + ',"Correct_ans":' + JSON.stringify(jsonData) + '}\n';
                        connection.release();
                        callback(200, null, resultJson);
                        return;

                    } else {
                        console.log(" error", results);
                        resultJson = '{"Total Score":' + score + '}\n';
                        connection.release();
                        callback(200, null, resultJson);
                        return;

                    }

                })

            })
            .catch((error) => {
                console.error('Error:', error);
            });
    });



}
function all_quiz(userdata, pool, callback) {


    pool.getConnection(function (err, connection) {

        squery = 'SELECT * FROM `quizzes`';
        connection.query(squery, function (err, results) {
            if (!err) {


                resultJson =
                    '{"replyCode":"success","replyMsg": "success", "data":' +
                    JSON.stringify(results) +
                    '}\n';
                connection.release();
                callback(200, null, resultJson);
                return;


            } else {
                resultJson =
                    '{"replyCode":"error","replyMsg":"' +
                    err.message +
                    '","cmd":"user_quizzes"}\n';
                connection.release();
                callback(400, null, resultJson);
                return;
            }
        });
    });
}



