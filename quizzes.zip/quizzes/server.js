// index.js

const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const controller = require('./controller.js')
const jwt = require('jsonwebtoken');

const app = express();
const port = 3000;


app.use(bodyParser.json());
var pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'quizzes'

});
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});


app.post('/login', function (req, res) {
    var userdata = req.body;
    controller.login(userdata, pool, function (http_status_code, err, response) {
        if (err) {
            console.log(err);
            throw err;
        }

        res.status(http_status_code).send(response);
    });
});
app.post('/register', function (req, res) {
    var userdata = req.body;
    controller.register(userdata, pool, function (http_status_code, err, response) {
        if (err) {
            console.log(err);
            throw err;
        }

        res.status(http_status_code).send(response);
    });
});
app.post('/add_quizzes', authenticateToken, function (req, res) {
    var userdata = req.body;
    controller.add_quizzes(userdata, pool, function (http_status_code, err, response) {
        if (err) {
            console.log(err);
            throw err;
        }

        res.status(http_status_code).send(response);
    });
});
app.post('/user_quizzes', authenticateToken, function (req, res) {
    var userdata = req.body;
    controller.user_quizzes(userdata, pool, function (http_status_code, err, response) {
        if (err) {
            console.log(err);
            throw err;
        }

        res.status(http_status_code).send(response);
    });
});
app.post('/open_quiz', authenticateToken, function (req, res) {
    var userdata = req.body;
    controller.open_quiz(userdata, pool, function (http_status_code, err, response) {
        if (err) {
            console.log(err);
            throw err;
        }

        res.status(http_status_code).send(response);
    });
});
app.post('/attempt_quiz', authenticateToken, function (req, res) {
    var userdata = req.body;
    controller.attempt_quiz(userdata, pool, function (http_status_code, err, response) {
        if (err) {
            console.log(err);
            throw err;
        }

        res.status(http_status_code).send(response);
    });
});
app.get('/all_quiz', authenticateToken, function (req, res) {
    var userdata = req.body;
    controller.all_quiz(userdata, pool, function (http_status_code, err, response) {
        if (err) {
            console.log(err);
            throw err;
        }

        res.status(http_status_code).send(response);
    });
});
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    jwt.verify(token, '123456789', (err, user) => {
        if (err) {
            return res.status(403).json({ message: 'Invalid token' });
        }

        // Pass the authenticated user to the next middleware or API handler
        req.user = user;
        next();
    });
}